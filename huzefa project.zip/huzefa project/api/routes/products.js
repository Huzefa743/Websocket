const express = require('express');
const router=express.Router();
const mysql=require('mysql');





router.get('/', (req, res, next) => {
  res.status(200).json({
    message : 'its get method work'
});
});




router.post('/', (req, res, next) => {
      res.status(200).json({
        message : 'its work post'
    });
});

router.get('/:productId', (req, res, next) => {
   const id=req.params.productId;
   if(id == 'special'){
     res.status(200).json({
       message: 'first line'
        
     });
    }
     else{
       res.status(200).json({
         message: 'second line'
       });
      }

});



module.exports = router;