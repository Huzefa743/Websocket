const express = require('express');
const app = express();
const mysql=require('mysql');

const productRoutes =require('./api/routes/products');

app.use('/products' , productRoutes);

app.use(express.static('views'));

module.exports= app;